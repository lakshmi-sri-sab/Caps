package com.example;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Base64;

public class RestconfClientManager {

    private String authHeader;

    public RestconfClientManager(String username, String password) {
        // Initialize SSL context to trust all certificates
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) { }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) { }
                }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create a hostname verifier that accepts all hostnames
            HostnameVerifier allHostsValid = (hostname, session) -> true;
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create the Basic Authentication header
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes());
        this.authHeader = "Basic " + new String(encodedAuth);
    }

    public String getConfig(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/yang-data+json"); // Set Accept header to application/yang-data+json
        conn.setRequestProperty("Authorization", authHeader); // Set Authorization header
        conn.setDoInput(true);

        // Debugging: Print response code and headers
        int responseCode = conn.getResponseCode();
        System.out.println("Response Code: " + responseCode);
        conn.getHeaderFields().forEach((key, value) -> System.out.println(key + ": " + value));

        // Handle 401 Unauthorized response
        if (responseCode == 401) {
            throw new Exception("Unauthorized: Check your credentials and try again.");
        }

        // Handle 406 Not Acceptable response
        if (responseCode == 406) {
            throw new Exception("Not Acceptable: The server cannot produce a response matching the list of acceptable values defined in the request's proactive content negotiation headers.");
        }

        try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            return response.toString();
        }
    }

    public void close() {
        // Clean up resources if needed
    }
}
